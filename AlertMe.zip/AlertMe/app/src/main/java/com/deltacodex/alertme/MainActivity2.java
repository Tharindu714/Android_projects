package com.deltacodex.alertme;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.pm.PackageManager;
import android.graphics.BitmapFactory;
import android.os.Build;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity2 extends AppCompatActivity {
    private static final String CHANNEL_ID = "channel1";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main2);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });


        NotificationManager notificationManager = getSystemService(NotificationManager.class);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel notificationChannel = new NotificationChannel(
                    CHANNEL_ID,
                    "Channel_NO1",
                    NotificationManager.IMPORTANCE_DEFAULT
            );
            notificationManager.createNotificationChannel(notificationChannel);
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(new String[]{android.Manifest.permission.POST_NOTIFICATIONS}, 101);
            }
        }

        Button button2 = findViewById(R.id.button2);
        button2.setOnClickListener(view -> {
            EditText editText_Title = findViewById(R.id.editTextText3);
            EditText editText_msg_content = findViewById(R.id.editTextText4);

            String title = String.valueOf(editText_Title.getText());
            String content = String.valueOf(editText_msg_content.getText());

            if (title.isEmpty()) {
                Toast.makeText(MainActivity2.this, "Please Enter The Message Title", Toast.LENGTH_SHORT).show();
            } else if (content.isEmpty()) {
                Toast.makeText(MainActivity2.this, "Please Enter The Message Content", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(MainActivity2.this, "Message Sent!!", Toast.LENGTH_SHORT).show();
                Notification notification = new NotificationCompat.Builder(MainActivity2.this, CHANNEL_ID)
                        .setSmallIcon(R.drawable.ic_launcher_foreground)
                        .setContentTitle(title)
                        .setContentText("Expand Message")
                        .setLargeIcon(BitmapFactory.decodeResource(getResources(),R.drawable.coc))
//                            .setStyle(
//                                    new NotificationCompat.BigTextStyle().bigText(content)
//                            )
                        .setStyle(
                                new NotificationCompat.BigPictureStyle()
                                        .bigPicture(BitmapFactory.decodeResource(getResources(),R.drawable.coc))
                                        .setSummaryText(content)
                        )
                        .build();

                notificationManager.notify(1, notification);

                editText_Title.setText("");
                editText_msg_content.setText("");
            }
        });

    }
}