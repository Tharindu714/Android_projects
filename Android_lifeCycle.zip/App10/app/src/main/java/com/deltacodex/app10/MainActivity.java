package com.deltacodex.app10;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    static String currentText = "Started";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_FULLSCREEN);

        Toast.makeText(MainActivity.this, "onCreate", Toast.LENGTH_SHORT).show();
        Log.i("App 10", "onCreate !!");

        TextView textView1;
        textView1 = findViewById(R.id.textView1);
        textView1.setText(MainActivity.currentText);

        Button button1 = findViewById(R.id.button);
        button1.setOnClickListener(view -> {
           Intent i = new Intent(MainActivity.this,HomeActivity.class);
           startActivity(i);
        });

        Button button2 = findViewById(R.id.button2);
        button2.setOnClickListener(view -> {
            @SuppressLint("CutPasteId") TextView textView2 = findViewById(R.id.textView1);
            MainActivity.currentText= "You got this";
            textView2.setText(MainActivity.currentText);
        });
    }

    @Override
    protected void onSaveInstanceState(@NonNull Bundle outState) {
        super.onSaveInstanceState(outState);
        TextView textView1 = findViewById(R.id.textView1);
        outState.putString("text1", textView1.getText().toString());
    }

    @Override
    protected void onRestoreInstanceState(@NonNull Bundle savedInstanceState) {
        super.onRestoreInstanceState(savedInstanceState);
        TextView textView1 = findViewById(R.id.textView1);
        textView1.setText(savedInstanceState.getString("text1"));
    }

    @Override
    protected void onStart() {
        super.onStart();
        Toast.makeText(MainActivity.this, "onStart", Toast.LENGTH_SHORT).show();
        Log.i("App 10", "onStart !!");
    }

    @Override
    protected void onResume() {
        super.onResume();
        Toast.makeText(MainActivity.this, "onResume", Toast.LENGTH_SHORT).show();
        Log.i("App 10", "onResume !!");
    }

    @Override
    protected void onPause() {
        super.onPause();
        Toast.makeText(MainActivity.this, "onPause", Toast.LENGTH_SHORT).show();
        Log.i("App 10", "onPause !!");
    }

    @Override
    protected void onStop() {
        super.onStop();
        Toast.makeText(MainActivity.this, "onStop", Toast.LENGTH_SHORT).show();
        Log.i("App 10", "onStop !!");
    }

    @Override
    protected void onRestart() {
        super.onRestart();
        Toast.makeText(MainActivity.this, "onRestart", Toast.LENGTH_SHORT).show();
        Log.i("App 10", "onRestart !!");
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        Toast.makeText(MainActivity.this, "onDestroy", Toast.LENGTH_SHORT).show();
        Log.i("App 10", "onDestroy !!");
    }
}
