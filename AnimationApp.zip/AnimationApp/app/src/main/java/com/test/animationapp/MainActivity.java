package com.test.animationapp;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.dynamicanimation.animation.DynamicAnimation;
import androidx.dynamicanimation.animation.FlingAnimation;
import androidx.dynamicanimation.animation.SpringAnimation;
import androidx.dynamicanimation.animation.SpringForce;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        Button btn4 = findViewById(R.id.button4);
        btn4.setOnClickListener(view -> {
            Intent intent = new Intent(MainActivity.this, MainActivity2.class);
            startActivity(intent);
        });

        Button btn5 = findViewById(R.id.button5);
        btn5.setOnClickListener(view -> {
            Intent intent = new Intent(MainActivity.this, MainActivity3.class);
            startActivity(intent);
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        SpringAnimation();
        FlingAnimation();
    }

    protected void SpringAnimation() {
        Button SpringButton = findViewById(R.id.button);
        SpringButton.setOnClickListener(view -> {
            ImageView soccerBall_img = findViewById(R.id.imageView);
            soccerBall_img.setTranslationY(0f);
            SpringAnimation springAnimation = new SpringAnimation(soccerBall_img, DynamicAnimation.TRANSLATION_Y);

            SpringForce springForce = new SpringForce();
            springForce.setStiffness(SpringForce.STIFFNESS_LOW);
            springForce.setDampingRatio(SpringForce.DAMPING_RATIO_MEDIUM_BOUNCY);
            springForce.setFinalPosition(600f);

            springAnimation.setSpring(springForce);
            springAnimation.start();
        });
    }

    protected void FlingAnimation() {
        Button flingButton = findViewById(R.id.button2);
        flingButton.setOnClickListener(view -> {
            ImageView soccerBall_img = findViewById(R.id.imageView);
//            soccerBall_img.setTranslationY(0f);
            FlingAnimation flingAnimation = new FlingAnimation(soccerBall_img, DynamicAnimation.TRANSLATION_Y);

            flingAnimation.setStartVelocity(2000f);
            flingAnimation.setFriction(2f);
            flingAnimation.start();
        });
    }
}