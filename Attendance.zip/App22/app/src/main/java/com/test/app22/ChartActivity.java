package com.test.app22;

import android.os.Bundle;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.github.mikephil.charting.animation.Easing;
import com.github.mikephil.charting.charts.BarChart;
import com.github.mikephil.charting.components.Legend;
import com.github.mikephil.charting.components.LegendEntry;
import com.github.mikephil.charting.data.BarData;
import com.github.mikephil.charting.data.BarDataSet;
import com.github.mikephil.charting.data.BarEntry;

import java.util.ArrayList;

public class ChartActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_chart);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        BarChart barChart = findViewById(R.id.barchart);
        ArrayList<BarEntry> barEntryArrayList = new ArrayList<>();
        barEntryArrayList.add(new BarEntry(10, MainActivity.attendance.getMonday()));
        barEntryArrayList.add(new BarEntry(20, MainActivity.attendance.getTuesday()));
        barEntryArrayList.add(new BarEntry(30, MainActivity.attendance.getWednesday()));
        barEntryArrayList.add(new BarEntry(40, MainActivity.attendance.getThursday()));
        barEntryArrayList.add(new BarEntry(50, MainActivity.attendance.getFriday()));
        barEntryArrayList.add(new BarEntry(60, MainActivity.attendance.getSaturday()));
        barEntryArrayList.add(new BarEntry(70, MainActivity.attendance.getSunday()));

        BarDataSet barDataSet = new BarDataSet(barEntryArrayList,"Student Attendance");

        ArrayList<Integer> colorArrayList = new ArrayList<>();
        colorArrayList.add(getColor(R.color.Monday));
        colorArrayList.add(getColor(R.color.Tuesday));
        colorArrayList.add(getColor(R.color.Wednesday));
        colorArrayList.add(getColor(R.color.Thursday));
        colorArrayList.add(getColor(R.color.Friday));
        colorArrayList.add(getColor(R.color.Saturday));
        colorArrayList.add(getColor(R.color.Sunday));

        barDataSet.setColors(colorArrayList);

        BarData barData = new BarData();
        barData.addDataSet(barDataSet);
        barData.setBarWidth(8);

        barChart.setPinchZoom(false);
        barChart.setScaleEnabled(false);
        barChart.animateY(1000, Easing.EaseInBounce);

        barChart.setFitBars(true);
        barChart.setData(barData);

        ArrayList<LegendEntry> LegendEntryArraylist = new ArrayList<>();
        LegendEntryArraylist.add(new LegendEntry(
                "MON",
                Legend.LegendForm.CIRCLE,
                Float.NaN,
                Float.NaN,
                null,getColor(R.color.Monday)));

        LegendEntryArraylist.add(new LegendEntry(
                "TUE",
                Legend.LegendForm.CIRCLE,
                Float.NaN,
                Float.NaN,
                null,getColor(R.color.Tuesday)));

        LegendEntryArraylist.add(new LegendEntry(
                "WED",
                Legend.LegendForm.CIRCLE,
                Float.NaN,
                Float.NaN,
                null,getColor(R.color.Wednesday)));

        LegendEntryArraylist.add(new LegendEntry(
                "THU",
                Legend.LegendForm.CIRCLE,
                Float.NaN,
                Float.NaN,
                null,getColor(R.color.Thursday)));

        LegendEntryArraylist.add(new LegendEntry(
                "FRI",
                Legend.LegendForm.CIRCLE,
                Float.NaN,
                Float.NaN,
                null,getColor(R.color.Friday)));

        LegendEntryArraylist.add(new LegendEntry(
                "SAT",
                Legend.LegendForm.CIRCLE,
                Float.NaN,
                Float.NaN,
                null,getColor(R.color.Saturday)));

        LegendEntryArraylist.add(new LegendEntry(
                "SUN",
                Legend.LegendForm.CIRCLE,
                Float.NaN,
                Float.NaN,
                null,getColor(R.color.Sunday)));

        barChart.getLegend().setCustom(LegendEntryArraylist);
        barChart.getLegend().setHorizontalAlignment(Legend.LegendHorizontalAlignment.LEFT);
        barChart.getLegend().setXEntrySpace(10);

        barChart.invalidate();
    }
}