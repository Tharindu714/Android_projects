package com.test.app22;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.ArrayList;

import model.Attendance;

public class MainActivity extends AppCompatActivity {

    public static Attendance attendance = new Attendance();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        Spinner spinner = findViewById(R.id.spinner);

        ArrayList<String> days = new ArrayList<>();
        days.add("Select Date");
        days.add("Monday");
        days.add("Tuesday");
        days.add("Wednesday");
        days.add("Thursday");
        days.add("Friday");
        days.add("Saturday");
        days.add("Sunday");

        ArrayAdapter<String> arrayAdapter = new ArrayAdapter<>(
                MainActivity.this,
                R.layout.custom_dropdown_item,
                days
        );
        spinner.setAdapter(arrayAdapter);

        Button btnSave = findViewById(R.id.button);
        btnSave.setOnClickListener(view -> {
            EditText editText = findViewById(R.id.editTextText);
            String attendanceCount = editText.getText().toString();

            if (attendanceCount.isEmpty()){
                Toast.makeText(MainActivity.this, "Please Enter Attendance Count", Toast.LENGTH_SHORT).show();
            } else {
                int count = Integer.parseInt(attendanceCount);
                String selectedDay = spinner.getSelectedItem().toString();

                if (selectedDay.equals("Select Date")){
                    Toast.makeText(this, "Please Select a Date", Toast.LENGTH_SHORT).show();
                }else{
                    switch (selectedDay) {
                        case "Monday":
                            attendance.setMonday(count);
                            spinner.setSelection(2);
                            break;
                        case "Tuesday":
                            attendance.setTuesday(count);
                            spinner.setSelection(3);
                            break;
                        case "Wednesday":
                            attendance.setWednesday(count);
                            spinner.setSelection(4);
                            break;
                        case "Thursday":
                            attendance.setThursday(count);
                            spinner.setSelection(5);
                            break;
                        case "Friday":
                            attendance.setFriday(count);
                            spinner.setSelection(6);
                            break;
                        case "Saturday":
                            attendance.setSaturday(count);
                            spinner.setSelection(7);
                            break;
                        case "Sunday":
                            attendance.setSunday(count);
                            spinner.setSelection(1);
                            break;
                    }
                    Toast.makeText(MainActivity.this, "Saved Successfully", Toast.LENGTH_SHORT).show();
                    editText.setText("");
                }
            }
        });

        Button btnView = findViewById(R.id.button2);
        btnView.setOnClickListener(view -> {
            Intent intent = new Intent(MainActivity.this, ChartActivity.class);
            startActivity(intent);
        });

    }
}