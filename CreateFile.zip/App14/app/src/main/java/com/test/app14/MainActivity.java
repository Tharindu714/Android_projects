package com.test.app14;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        Button btn1 = findViewById(R.id.button);
        Button btn2 = findViewById(R.id.button2);
        TextView textView = findViewById(R.id.textView);

        btn1.setOnClickListener(view -> {
            try {
                // Create and write to the file in the app's internal storage
                File f = new File(getApplicationContext().getFilesDir(), "A.txt");
                FileWriter fw = new FileWriter(f);
                BufferedWriter bw = new BufferedWriter(fw);
                bw.write("Hello! This is an Awesome App");
                bw.newLine();
                bw.write("Delta Codex Software Solution"); 
                bw.flush();
                bw.close();
                Toast.makeText(this, "File created and text written successfully!", Toast.LENGTH_SHORT).show();
            } catch (IOException e) {
                e.printStackTrace();
                Toast.makeText(this, "Error writing to file: " + e.getMessage(), Toast.LENGTH_LONG).show();
            }
        });

        btn2.setOnClickListener(view -> {
            try {
                // Read the file from the app's internal storage
                File f = new File(getApplicationContext().getFilesDir(), "A.txt");
                BufferedReader br = new BufferedReader(new FileReader(f));
                StringBuilder content = new StringBuilder();
                String line;

                while ((line = br.readLine()) != null) {
                    content.append(line).append("\n");
                }
                br.close();

                // Display the content in the TextView
                textView.setText(content.toString());
            } catch (IOException e) {
                e.printStackTrace();
                Toast.makeText(this, "Error writing to file: " + e.getMessage(), Toast.LENGTH_LONG).show();
            }
        });
    }
}