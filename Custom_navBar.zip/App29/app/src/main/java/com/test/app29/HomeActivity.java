package com.test.app29;

import android.os.Bundle;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import com.google.android.material.navigation.NavigationView;
import com.test.app29.navigation.CategoryFragment;
import com.test.app29.navigation.DashboardFragment;
import com.test.app29.navigation.ProductFragment;

public class HomeActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_home);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.drawerLayout1), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        DrawerLayout drawerLayout = findViewById(R.id.drawerLayout1);
        Toolbar toolbar = findViewById(R.id.toolbar);
        NavigationView navigationView = findViewById(R.id.navigationView1);
        navigationView.setNavigationItemSelectedListener(item -> {


            if (item.getItemId() == R.id.nav_menu_dashboard) {
                LoadFragment(new DashboardFragment());

            } else if (item.getItemId() == R.id.nav_menu_category) {
                LoadFragment(new CategoryFragment());

            } else if (item.getItemId() == R.id.nav_menu_product) {
                LoadFragment(new ProductFragment());
            }
            toolbar.setTitle(item.getTitle());
            drawerLayout.closeDrawers();
            return true;
        });
    }

    private void LoadFragment(Fragment fragment) {
        FragmentManager fragmentManager = getSupportFragmentManager();
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
        fragmentTransaction.replace(R.id.fragment_container_view1, fragment, null)
                .setReorderingAllowed(true).commit();
    }
}