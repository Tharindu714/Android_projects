package com.deltacodex.frag;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import org.w3c.dom.Text;

public class A1Activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_a1);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        Button activity_btn = findViewById(R.id.Activity_btn1);
        activity_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                TextView activityTextView = findViewById(R.id.Activity_textView1);
                activityTextView.setText("I changed this !");
            }
        });

        Button activity_btn2 = findViewById(R.id.Activity_btn2);
        activity_btn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                FragmentManager fragMgt = getSupportFragmentManager();
                FragmentTransaction frgTrans = fragMgt.beginTransaction();
                frgTrans.replace(R.id.Frag_container, F1Fragment.class, null).setReorderingAllowed(true).commit();
            }
        });

        Button activity_btn3 = findViewById(R.id.Activity_btn3);
        activity_btn3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                TextView fragTextView = findViewById(R.id.fragment_textView1);
                fragTextView.setText("Changed by Activity");
            }
        });
    }
}