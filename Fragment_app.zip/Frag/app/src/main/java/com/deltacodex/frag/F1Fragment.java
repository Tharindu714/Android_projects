package com.deltacodex.frag;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

public class F1Fragment extends Fragment {

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_f1, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        Button fragment_btn = getView().findViewById(R.id.frag_btn1);
        fragment_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                TextView fragmeTextView = getView().findViewById(R.id.fragment_textView1);
                fragmeTextView.setText("Changed by Fragment");
            }
        });

        Button fragment_btn2 = getView().findViewById(R.id.frag_btn2);
        fragment_btn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                TextView activityTextView1 = getActivity().findViewById(R.id.Activity_textView1);
                activityTextView1.setText("Changed by Fragment_btn2");
            }
        });
    }
}