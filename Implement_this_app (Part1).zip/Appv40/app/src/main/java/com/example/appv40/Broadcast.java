package com.example.appv40;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.util.Log;

public class Broadcast extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
//        Log.i("Broadcast","Hello! I am the Broadcast Receiver");
        boolean state = intent.getBooleanExtra("state", false);

        if (state){
            Intent i = new Intent(context,BroadcastActivity.class);
            context.startActivity(i);
        }
    }
}
