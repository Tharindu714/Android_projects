package com.example.appv40;

import android.annotation.SuppressLint;
import android.app.SearchManager;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    Broadcast bc;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

 Button button1 = findViewById(R.id.button);
        button1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
//                Intent i = new Intent("android.media.action.STILL_IMAGE_CAMERA");

//                Intent i = new Intent("com.example.App v4.1.MainActivity");

//                Intent i = new Intent();
//                i.setClassName("com.example.appv41","com.example.appv41.MainActivity");

//                Intent i = new Intent(Intent.ACTION_VIEW);
//                Uri uri = Uri.parse("geo:6.8301115674392765, 80.99024065370513");
//                i.setData(uri);

//                Intent i  = new Intent(Intent.ACTION_CALL);
//                Uri uri = Uri.parse("tel:0572223351");
//                i.setData(uri);

//                Intent i = new Intent(Intent.ACTION_WEB_SEARCH);
//                i.putExtra(SearchManager.QUERY,"chanakaelectronics.com");

//                Intent i = new Intent(MainActivity.this, HomeActivity.class);
//                i.putExtra("x",10);
//              startActivity(i);

            }
        });

        bc = new Broadcast();
        IntentFilter intentFilter = new IntentFilter(Intent.ACTION_AIRPLANE_MODE_CHANGED);
        registerReceiver(bc, intentFilter);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        unregisterReceiver(bc);
    }
}