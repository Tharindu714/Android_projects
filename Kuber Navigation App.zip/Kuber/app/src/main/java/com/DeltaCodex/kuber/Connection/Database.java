package com.DeltaCodex.kuber.Connection;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

import com.DeltaCodex.kuber.DTO.Location_DTO;

import java.util.ArrayList;

public class Database extends SQLiteOpenHelper {
    private static final String DATABASE_SQLite = "Kuber_map.sqlite",
            TABLE_NAME = "locations",
            COL_ID = "id",
            COL_NAME = "name",
            COL_LATITUDE = "latitude",
            COL_LONGITUDE = "longitude";

    public Database(@Nullable Context context) {
        super(context, Database.DATABASE_SQLite, null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        sqLiteDatabase.execSQL("CREATE TABLE IF NOT EXISTS " + Database.TABLE_NAME + "(" +
                Database.COL_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                Database.COL_NAME + " TEXT, " +
                Database.COL_LATITUDE + " DOUBLE," +
                Database.COL_LONGITUDE + " DOUBLE)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int oldVersion, int newVersion) {
        sqLiteDatabase.execSQL("DROP TABLE IF EXISTS " + Database.TABLE_NAME);
        onCreate(sqLiteDatabase);
    }

    public boolean addLocation(Location_DTO locationDto) {
        SQLiteDatabase writableDatabase = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(Database.COL_NAME, locationDto.getName());
        values.put(Database.COL_LATITUDE, locationDto.getLatitude());
        values.put(Database.COL_LONGITUDE, locationDto.getLongitude());
        long inserted = writableDatabase.insert(Database.TABLE_NAME, null, values);
        return inserted != -1;
    }

    public void addLocation(ArrayList<Location_DTO> dtoArrayList) {
        SQLiteDatabase writableDatabase = this.getWritableDatabase();
        for (Location_DTO locationDto : dtoArrayList) {
            ContentValues values = new ContentValues();
            values.put(Database.COL_NAME, locationDto.getName());
            values.put(Database.COL_LATITUDE, locationDto.getLatitude());
            values.put(Database.COL_LONGITUDE, locationDto.getLongitude());
            writableDatabase.insert(Database.TABLE_NAME, null, values);
        }
    }

    public ArrayList<Location_DTO> getLocations() {
        SQLiteDatabase readableDatabase = this.getReadableDatabase();
        ArrayList<Location_DTO> locations = new ArrayList<>();
        @SuppressLint("Recycle")
        Cursor cursor = readableDatabase.rawQuery("SELECT * FROM " + Database.TABLE_NAME, null);
        if (cursor.moveToFirst()) {
            do {
                Location_DTO dto = new Location_DTO(cursor.getString(1),
                        cursor.getDouble(2),
                        cursor.getDouble(3));
                locations.add(dto);
            } while (cursor.moveToNext());
        }
        return locations;
    }

    public Location_DTO getLocationById(int id) {
        SQLiteDatabase readableDatabase = this.getReadableDatabase();
        @SuppressLint("Recycle")
        Cursor cursor = readableDatabase.rawQuery("SELECT * FROM " + Database.TABLE_NAME + " WHERE id=" + id, null);
        if (cursor.moveToFirst()) {
            return new Location_DTO(
                    cursor.getInt(0),
                    cursor.getString(1),
                    cursor.getDouble(2),
                    cursor.getDouble(3)
            );
        }
        return null;
    }
}
