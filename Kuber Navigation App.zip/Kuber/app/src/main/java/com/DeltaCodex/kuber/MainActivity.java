package com.DeltaCodex.kuber;

import android.os.Bundle;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import com.DeltaCodex.kuber.Connection.Database;
import com.DeltaCodex.kuber.DTO.Location_DTO;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptor;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.CameraPosition;
import com.google.android.gms.maps.model.JointType;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.maps.model.PolylineOptions;
import com.google.android.gms.maps.model.RoundCap;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    private Database sqlite_db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.frame_layout_kuber), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        this.sqlite_db = new Database(this);
        insertLocation();
        insertLocations();

        SupportMapFragment supportMapFragment = new SupportMapFragment();
        FragmentManager fragmentManager = getSupportFragmentManager();
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
        fragmentTransaction.add(R.id.frame_layout_kuber, supportMapFragment);
        fragmentTransaction.commit();

        Location_DTO locationById = sqlite_db.getLocationById(1);

        supportMapFragment.getMapAsync(new OnMapReadyCallback() {
            @Override
            public void onMapReady(@NonNull GoogleMap googleMap) {
                googleMap.animateCamera(
                        CameraUpdateFactory.newCameraPosition(
                                new CameraPosition.Builder().target(
                                                new LatLng(locationById.getLatitude(), locationById.getLongitude()))
                                        .zoom(18).build()
                        )
                );
                ArrayList<LatLng> lines = new ArrayList<>();
                for (Location_DTO locationDto : sqlite_db.getLocations()) {
                    lines.add(
                            new LatLng(locationDto.getLatitude(), locationDto.getLongitude())
                    );
                }
                googleMap.addPolyline(
                        new PolylineOptions()
                                .addAll(lines)
                                .width(15)
                                .color(getColor(R.color.roadMap))
                                .startCap(new RoundCap())
                                .endCap(new RoundCap())
                                .jointType(JointType.ROUND)
                );
                LatLng last = new LatLng(lines.get(lines.size() - 1).latitude, lines.get(lines.size() - 1).longitude);

                googleMap.addMarker(
                        new MarkerOptions()
                                .position(last)
                                .title("End Location")
                                .icon(BitmapDescriptorFactory.fromResource(R.drawable.location))
                ).showInfoWindow();
            }
        });
    }

    public void insertLocation() {
        Location_DTO locationDto = new Location_DTO("Lotus Tower", 6.927312058075259, 79.8583237154196);
        boolean added = sqlite_db.addLocation(locationDto);
        if (added) {
            Toast.makeText(this, "Your Destination has selected", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "Location Added Failed", Toast.LENGTH_SHORT).show();
        }
    }

    private void insertLocations() {
        Location_DTO location_point1 = new Location_DTO("First Location", 6.926761443538267, 79.85869282925023);
        Location_DTO location_point2 = new Location_DTO("Second Location", 6.926571458256041, 79.85823351217178);
        Location_DTO location_point3 = new Location_DTO("Third Location", 6.926872268250882, 79.85788264495909);
        Location_DTO location_point4 = new Location_DTO("Forth Location", 6.927236406408988, 79.85792411108423);
        Location_DTO location_point5 = new Location_DTO("Fifth Location", 6.927429557839585, 79.85806764767125);
        Location_DTO location_point6 = new Location_DTO("Sixth Location", 6.927689203915054, 79.85768488340995);
        Location_DTO location_point7 = new Location_DTO("Seventh Location", 6.927948849832842, 79.85717134139864);
        Location_DTO location_point8 = new Location_DTO("Eighth Location", 6.928553634282096, 79.8575477262268);
        Location_DTO location_point9 = new Location_DTO("Ninth Location", 6.928461808420906, 79.85794005956464);

        ArrayList<Location_DTO> List = new ArrayList<>();
        List.add(location_point1);
        List.add(location_point2);
        List.add(location_point3);
        List.add(location_point4);
        List.add(location_point5);
        List.add(location_point6);
        List.add(location_point7);
        List.add(location_point8);
        List.add(location_point9);
        sqlite_db.addLocation(List);
    }
}