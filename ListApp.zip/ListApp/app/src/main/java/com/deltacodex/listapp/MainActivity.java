package com.deltacodex.listapp;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.deltacodex.listapp.model.User;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        Button btn1 = findViewById(R.id.LoadData_btn);
        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ArrayList<User> userList = new ArrayList<>();
                userList.add(new User("U001", "Tharindu", "0751441764", "Bandarawela"));
                userList.add(new User("U002", "Sadeesha", "0721001764", "Badulla"));
                userList.add(new User("U003", "Kasuni", "0761201769", "Kalupahana"));
                userList.add(new User("U004", "Samadhi", "0745009876", "Mirahawatta"));
                userList.add(new User("U005", "Dhanushka", "0711641064", "BadalKumbura"));
                userList.add(new User("U006", "Maleesha", "0781841094", "Walimada"));

                RecyclerView recyclerView1 = findViewById(R.id.recyclerView);

                LinearLayoutManager layoutManager = new LinearLayoutManager(MainActivity.this);
                recyclerView1.setLayoutManager(layoutManager);
                layoutManager.setOrientation(recyclerView1.VERTICAL);
                UserAdapter userAdapter = new UserAdapter(userList);
                recyclerView1.setAdapter(userAdapter);

            }
        });
    }
}


class UserAdapter extends RecyclerView.Adapter<UserAdapter.UserViewHolder> {

    class UserViewHolder extends RecyclerView.ViewHolder {

        public TextView textView1;

        public TextView textView2;

        public TextView textView3;

        public TextView button1;

        public UserViewHolder(@NonNull View itemView) {
            super(itemView);

            textView1 = itemView.findViewById(R.id.tv1);
            textView2 = itemView.findViewById(R.id.tv2);
            textView3 = itemView.findViewById(R.id.tv3);
            button1 = itemView.findViewById(R.id.btn1);
        }
    }

    public ArrayList<User> userArrayList;

    public UserAdapter(ArrayList<User> userArrayList) {
        this.userArrayList = userArrayList;
    }

    @NonNull
    @Override
    public UserViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        View view = layoutInflater.inflate(R.layout.user_view, parent, false);
        UserViewHolder userViewHolder = new UserViewHolder(view);
        return userViewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull UserViewHolder holder, int position) {
        holder.textView1.setText(userArrayList.get(position).getId());
        holder.textView2.setText(userArrayList.get(position).getName());
        holder.textView3.setText(userArrayList.get(position).getCity());
        String mobile = userArrayList.get(position).getMobile();
        holder.button1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(view.getContext(), mobile, Toast.LENGTH_LONG).show();
            }
        });
    }

    @Override
    public int getItemCount() {
        return this.userArrayList.size();
    }

}