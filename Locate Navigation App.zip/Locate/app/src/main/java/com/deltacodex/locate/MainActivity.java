package com.deltacodex.locate;

import android.os.Bundle;
import android.widget.Button;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.CameraPosition;
import com.google.android.gms.maps.model.JointType;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.maps.model.PolylineOptions;
import com.google.android.gms.maps.model.RoundCap;

import java.util.ArrayList;
import java.util.Random;

public class MainActivity extends AppCompatActivity {

    private static final ArrayList<ArrayList<LatLng>> routeArrayList = new ArrayList<>();

    private static final int[] colorArray = {
            R.color.clr1,
            R.color.clr2,
            R.color.clr3,
            R.color.clr4,
            R.color.clr5,
            R.color.clr6,
            R.color.clr7,
    };
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        ArrayList<LatLng> Route = new ArrayList<>();

        SupportMapFragment supportMapFragment = new SupportMapFragment();
        FragmentManager fragmentManager = getSupportFragmentManager();
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
        fragmentTransaction.add(R.id.frame_layout_locate, supportMapFragment);
        fragmentTransaction.commit();

        Button Add_a_place = findViewById(R.id.Add_a_place);
        Add_a_place.setEnabled(false);
        Add_a_place.setBackgroundColor(getColor(R.color.black));

        Button save_a_place = findViewById(R.id.save_a_place);
        save_a_place.setEnabled(false);
        save_a_place.setBackgroundColor(getColor(R.color.black));

        Button view_a_place = findViewById(R.id.view_a_place);
        view_a_place.setEnabled(false);
        view_a_place.setBackgroundColor(getColor(R.color.black));

        supportMapFragment.getMapAsync(googleMap -> {
            LatLng latLng = new LatLng(6.822235782273089, 81.00463701675478);

            googleMap.animateCamera(
                    CameraUpdateFactory.newCameraPosition(
                            new CameraPosition.Builder().target(latLng).zoom(16).build()));

            Add_a_place.setEnabled(true);
            Add_a_place.setBackgroundColor(getColor(R.color.add_a_place));
            Add_a_place.setOnClickListener(view -> {
                Add_a_place.setEnabled(false);
                Add_a_place.setBackgroundColor(getColor(R.color.black));

                save_a_place.setEnabled(true);
                save_a_place.setBackgroundColor(getColor(R.color.save_a_place));

                Route.clear();

                googleMap.setOnMapClickListener(latLng1 -> {
                    googleMap.addMarker(
                            new MarkerOptions().title("Latitude: " + latLng1.latitude + ", Longitude: " + latLng1.longitude)
                                    .position(latLng1).icon(BitmapDescriptorFactory.fromResource(R.drawable.location))
                    ).showInfoWindow();
                    Route.add(latLng1);
                });
            });

            Random random = new Random();

            save_a_place.setOnClickListener(view -> {

                googleMap.setOnMapClickListener(null);
                routeArrayList.add(new ArrayList<>(Route));
                Add_a_place.setEnabled(true);
                Add_a_place.setBackgroundColor(getColor(R.color.add_a_place));

                save_a_place.setEnabled(false);
                save_a_place.setBackgroundColor(getColor(R.color.black));

                view_a_place.setEnabled(true);
                view_a_place.setBackgroundColor(getColor(R.color.view_a_place));

            });

            view_a_place.setOnClickListener(view -> {
                for (ArrayList<LatLng> route : routeArrayList) {
//                    int randomColor = Color.rgb(
//                            random.nextInt(256),
//                            random.nextInt(256),
//                            random.nextInt(256)
//                    );
                    googleMap.addPolyline(
                            new PolylineOptions()
                                    .addAll(route)
                                    .color(getColorFromArray())
                                    .width(10).startCap(new RoundCap()).endCap(new RoundCap())
                                    .jointType(JointType.ROUND));
                }

            });
        });
    }

    private int getColorFromArray(){
        Random random_color = new Random();
       int colorId =  colorArray[random_color.nextInt(colorArray.length)];
       return getColor(colorId);
    }
}