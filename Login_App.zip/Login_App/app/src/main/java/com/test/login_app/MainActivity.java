package com.test.login_app;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.google.gson.JsonSyntaxException;

import java.io.IOException;

import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        Button btn1 = findViewById(R.id.button);
        btn1.setOnClickListener(view -> {
            EditText editTextPhone = findViewById(R.id.editTextPhone);
            EditText editTextNumberPassword = findViewById(R.id.editTextNumberPassword);

            String mobile = editTextPhone.getText().toString().trim();
            String password = editTextNumberPassword.getText().toString().trim();

            if (mobile.isEmpty() || password.isEmpty()) {
                Toast.makeText(MainActivity.this, "Please fill in all fields", Toast.LENGTH_SHORT).show();
                return;
            }

            new Thread(() -> {
                Gson gson = new Gson();
                JsonObject jsonObject = new JsonObject();
                jsonObject.addProperty("mobile", mobile);
                jsonObject.addProperty("password", password);

                OkHttpClient okHttpClient = new OkHttpClient();
                RequestBody requestBody = RequestBody.create(gson.toJson(jsonObject), MediaType.get("application/json"));
                Request request = new Request.Builder().url("https://3167-2402-4000-23e0-19b7-7571-178d-af86-1ae4.ngrok-free.app/OkHttp/Signin").post(requestBody).build();

                try {
                    Response response = okHttpClient.newCall(request).execute();
                    if (!response.isSuccessful()) {
                        throw new IOException("Unexpected code " + response);
                    }

                    String responseText = response.body().string();
                    JsonObject responJsonObject = gson.fromJson(responseText, JsonObject.class);

                    if (responJsonObject.get("message").getAsString().equals("Success")) {
                        runOnUiThread(() -> {
                            Intent intent = new Intent(MainActivity.this, HomeActivity.class);
                            editTextPhone.setText("");
                            editTextNumberPassword.setText("");
                            intent.putExtra("userJson", gson.toJson(responJsonObject.get("user").getAsJsonObject()));
                            startActivity(intent);
                        });
                    } else {
                        runOnUiThread(() -> Toast.makeText(MainActivity.this, "Invalid Details", Toast.LENGTH_SHORT).show());
                    }
                } catch (IOException | JsonSyntaxException e) {
                    runOnUiThread(() -> Toast.makeText(MainActivity.this, "An error occurred. Please try again.", Toast.LENGTH_SHORT).show());
                }
            }).start();
        });
    }

}