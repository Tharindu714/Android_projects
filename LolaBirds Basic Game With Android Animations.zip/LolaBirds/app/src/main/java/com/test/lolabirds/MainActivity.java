package com.test.lolabirds;

import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.dynamicanimation.animation.DynamicAnimation;
import androidx.dynamicanimation.animation.FlingAnimation;
import androidx.dynamicanimation.animation.SpringAnimation;
import androidx.dynamicanimation.animation.SpringForce;

public class MainActivity extends AppCompatActivity {

    private ImageView birdImage;
    private ImageView targetImage;
    private boolean isLaunched = false; // To track if the bird is in motion

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        birdImage = findViewById(R.id.birdImage);
        targetImage = findViewById(R.id.targetImage);

        SpringAnimation();
        FlingAnimation();

    }

    @Override
    protected void onResume() {
        super.onResume();
        // Initialize animations on resume
        SpringAnimation();
        FlingAnimation();
    }

    protected void SpringAnimation() {
        Button springButton = findViewById(R.id.button);
        springButton.setOnClickListener(view -> {
            if (isLaunched) return; // Prevent new animation if bird is in motion

            // Reset bird position
            birdImage.setTranslationY(0f);
            birdImage.setTranslationX(0f);

            // Create a SpringAnimation for bouncing
            SpringAnimation springAnimation = new SpringAnimation(birdImage, DynamicAnimation.TRANSLATION_Y);

            SpringForce springForce = new SpringForce();
            springForce.setStiffness(SpringForce.STIFFNESS_LOW);
            springForce.setDampingRatio(SpringForce.DAMPING_RATIO_MEDIUM_BOUNCY);
            springForce.setFinalPosition(100f);

            springAnimation.setSpring(springForce);
            springAnimation.start();
        });
    }

    protected void FlingAnimation() {
        Button flingButton = findViewById(R.id.button2);
        flingButton.setOnClickListener(view -> {
            if (isLaunched) return; // Prevent new animation if bird is in motion

            isLaunched = true;
            FlingAnimation flingAnimationX = new FlingAnimation(birdImage, DynamicAnimation.TRANSLATION_X);
            FlingAnimation flingAnimationY = new FlingAnimation(birdImage, DynamicAnimation.TRANSLATION_Y);

            // Set fling properties
            flingAnimationX.setStartVelocity(3000f); // Horizontal velocity
            flingAnimationX.setFriction(2f);

            flingAnimationY.setStartVelocity(-4800f); // Upward velocity (negative for upward)
            flingAnimationY.setFriction(2f);

            // Start both animations
            flingAnimationX.start();
            flingAnimationY.start();

            // Detect when the bird "lands" and bounce
            flingAnimationY.addEndListener((animation, canceled, value, velocity) -> {
                if (velocity < 0.1f) { // If bird slows down enough
                    isLaunched = false; // Allow new animations
                    startBounceAnimation();
                }
            });
        });
    }

    private void startBounceAnimation() {
        // Create a SpringAnimation for bouncing
        SpringAnimation springAnimation = new SpringAnimation(birdImage, DynamicAnimation.TRANSLATION_Y);

        SpringForce springForce = new SpringForce();
        springForce.setStiffness(SpringForce.STIFFNESS_LOW);
        springForce.setDampingRatio(SpringForce.DAMPING_RATIO_MEDIUM_BOUNCY);
        springForce.setFinalPosition(200f);

        springAnimation.setSpring(springForce);
        springAnimation.start();

        // Check for collision with the target
        springAnimation.addEndListener((animation, canceled, value, velocity) -> checkCollision());
    }

    private void checkCollision() {
        // Simple collision detection
        float birdX = birdImage.getX();
        float birdY = birdImage.getY();

        float targetX = targetImage.getX();
        float targetY = targetImage.getY();

        float targetWidth = targetImage.getWidth();
        float targetHeight = targetImage.getHeight();

        if (birdX + birdImage.getWidth() > targetX && birdX < targetX + targetWidth &&
                birdY + birdImage.getHeight() > targetY && birdY < targetY + targetHeight) {
            // Collision detected
            Toast.makeText(this, "Hit!", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "Miss!", Toast.LENGTH_SHORT).show();
        }
    }
}