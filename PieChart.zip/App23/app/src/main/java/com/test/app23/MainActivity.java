package com.test.app23;

import android.os.Bundle;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.github.mikephil.charting.animation.Easing;
import com.github.mikephil.charting.charts.PieChart;
import com.github.mikephil.charting.components.Legend;
import com.github.mikephil.charting.components.LegendEntry;
import com.github.mikephil.charting.data.PieData;
import com.github.mikephil.charting.data.PieDataSet;
import com.github.mikephil.charting.data.PieEntry;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        PieChart pieChart1 = findViewById(R.id.pieChart1);

        ArrayList<PieEntry> pieEntryArrayList = new ArrayList<>();
        pieEntryArrayList.add(new PieEntry(70, "Android"));
        pieEntryArrayList.add(new PieEntry(30, "React Native"));
        pieEntryArrayList.add(new PieEntry(20, "Flutter"));
        pieEntryArrayList.add(new PieEntry(50, "iOS"));

        PieDataSet pieDataSet = new PieDataSet(pieEntryArrayList, "Charts");

        ArrayList<Integer> colorArrayList = new ArrayList<>();
        colorArrayList.add(getColor(R.color.android));
        colorArrayList.add(getColor(R.color.react));
        colorArrayList.add(getColor(R.color.flutter));
        colorArrayList.add(getColor(R.color.ios));
        pieDataSet.setColors(colorArrayList);


        PieData pieData = new PieData();
        pieData.setDataSet(pieDataSet);
        pieData.setValueTextSize(18);
        pieData.setValueTextColor(getColor(R.color.white));

        pieChart1.setData(pieData);
        pieChart1.animateY(2000, Easing.EaseInCirc);

        pieChart1.setCenterText("Mobile Development");
        pieChart1.setCenterTextColor(getColor(R.color.color_center));
        pieChart1.setCenterTextSize(18);

        ArrayList<LegendEntry> LegendEntryArraylist = new ArrayList<>();
        LegendEntryArraylist.add(new LegendEntry(
                "Android",
                Legend.LegendForm.CIRCLE,
                Float.NaN,
                Float.NaN,
                null, getColor(R.color.android)));

        LegendEntryArraylist.add(new LegendEntry(
                "React Native",
                Legend.LegendForm.CIRCLE,
                Float.NaN,
                Float.NaN,
                null, getColor(R.color.react)));

        LegendEntryArraylist.add(new LegendEntry(
                "Flutter",
                Legend.LegendForm.CIRCLE,
                Float.NaN,
                Float.NaN,
                null, getColor(R.color.flutter)));

        LegendEntryArraylist.add(new LegendEntry(
                "iOS",
                Legend.LegendForm.CIRCLE,
                Float.NaN,
                Float.NaN,
                null, getColor(R.color.ios)));

        pieChart1.getLegend().setCustom(LegendEntryArraylist);
        pieChart1.getLegend().setHorizontalAlignment(Legend.LegendHorizontalAlignment.LEFT);
        pieChart1.getLegend().setXEntrySpace(35);
        pieChart1.getLegend().setTextColor(getColor(R.color.white));
        pieChart1.setDescription(null);
        pieChart1.invalidate();
    }
}