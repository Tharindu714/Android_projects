package com.test.practicleday01;

import android.app.AlertDialog;
import android.os.Bundle;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        Button regButton = findViewById(R.id.regBtn);
        regButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast toastErr = new Toast(MainActivity.this);

                LayoutInflater layoutInflater = LayoutInflater.from(MainActivity.this);
                View toast_error_view = layoutInflater.inflate(R.layout.toast, null, false);
                TextView toast_Error_message = toast_error_view.findViewById(R.id.toastErrMsg);

                toastErr.setView(toast_error_view);
                toastErr.setGravity(Gravity.BOTTOM, 0, 0);
                toastErr.setDuration(Toast.LENGTH_LONG);

                View alert_info_view = layoutInflater.inflate(R.layout.alert_info,null,false);
                TextView alertMsgTextView = alert_info_view.findViewById(R.id.alertText);


                EditText title_TextView = findViewById(R.id.productTitle);
                EditText description_TextView = findViewById(R.id.productDesc);
                EditText category_TextView = findViewById(R.id.productCategory);
                EditText brand_TextView = findViewById(R.id.brandName);
                EditText qty_TextView = findViewById(R.id.productQTY);
                EditText price_TextView = findViewById(R.id.productPrice);

                Animation animation = AnimationUtils.loadAnimation(MainActivity.this,R.anim.animation1);
                regButton.startAnimation(animation);

                if (title_TextView.getText().toString().isEmpty()) {
                    toast_Error_message.setText(R.string.emptyTitle);
                    toastErr.show();
                    regButton.startAnimation(animation);
                } else if (description_TextView.getText().toString().isEmpty()) {
                    toast_Error_message.setText(R.string.emptyDesc);
                    toastErr.show();
                    regButton.startAnimation(animation);
                } else if (category_TextView.getText().toString().isEmpty()) {
                    toast_Error_message.setText(R.string.emptyCat);
                    toastErr.show();
                    regButton.startAnimation(animation);
                } else if (brand_TextView.getText().toString().isEmpty()) {
                    toast_Error_message.setText(R.string.emptybrand);
                    toastErr.show();
                    regButton.startAnimation(animation);
                } else if (qty_TextView.getText().toString().isEmpty()) {
                    toast_Error_message.setText(R.string.emptyQty);
                    toastErr.show();
                    regButton.startAnimation(animation);
                } else if (price_TextView.getText().toString().isEmpty()) {
                    toast_Error_message.setText(R.string.emptyPrice);
                    toastErr.show();
                    regButton.startAnimation(animation);
                }else{
                    alertMsgTextView.setText(R.string.Alert_content);
                    new AlertDialog.Builder(MainActivity.this).setView(alert_info_view).show();
                }
            }
        });
    }
}