package com.test.notify;

import android.Manifest;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.widget.Button;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationCompat;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Request Notification Permission (Android 13+)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 101);
            }
        }

        // Create Notification Channel (Only Once)
        NotificationManager notificationManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel notificationChannel = new NotificationChannel(
                    "C1", "Channel1", NotificationManager.IMPORTANCE_HIGH
            );
            notificationManager.createNotificationChannel(notificationChannel);
        }

        // Button Click Listener
        Button button1 = findViewById(R.id.button);
        button1.setOnClickListener(view -> {

            Intent intent = new Intent(MainActivity.this, MainActivity2.class);
            PendingIntent pendingIntent = PendingIntent.getActivity(
                    MainActivity.this,
                    100, intent, PendingIntent.FLAG_IMMUTABLE
            );

            NotificationCompat.Action action = new NotificationCompat.Action.Builder(
                    R.drawable.baseline_adb_24, "View", pendingIntent
            ).build();

            Notification notification = new NotificationCompat
                    .Builder(MainActivity.this, "C1")
                    .setContentTitle("Hello!!")
                    .setContentText("This is a Simple Notification")
                    .setSmallIcon(R.drawable.baseline_adb_24)
                    .setPriority(NotificationCompat.PRIORITY_HIGH)  // Ensure visibility
                    .setDefaults(Notification.DEFAULT_ALL)  // Enable sound, vibration, lights
                    .addAction(action)
                    .build();

            notificationManager.notify(100, notification);
        });
    }
}
