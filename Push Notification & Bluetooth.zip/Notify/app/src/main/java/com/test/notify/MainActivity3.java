package com.test.notify;

import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothManager;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.Set;

public class MainActivity3 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main3);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        Button bluetoothBtn = findViewById(R.id.button2);
        bluetoothBtn.setOnClickListener(view -> {
            BluetoothManager btMgt = getSystemService(BluetoothManager.class);
            BluetoothAdapter btAdapter = btMgt.getAdapter();

            if (btAdapter == null) {
                Log.i("app31-log", "Bluetooth Not Available");
                Toast.makeText(MainActivity3.this, "Bluetooth Not Available", Toast.LENGTH_SHORT).show();
            } else {
                Log.i("app31-log", "Bluetooth Available");
                Toast.makeText(MainActivity3.this, "Bluetooth Available", Toast.LENGTH_SHORT).show();

                if (btAdapter.isEnabled()) {
                    Log.i("app31-log", "Bluetooth is activated");
                    Toast.makeText(MainActivity3.this, "Bluetooth On", Toast.LENGTH_SHORT).show();
                } else {
                    Log.i("app31-log", "Bluetooth is deactivated");
                    Toast.makeText(MainActivity3.this, "Bluetooth Off", Toast.LENGTH_SHORT).show();

                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) { // Android 12+
                        if (checkSelfPermission(android.Manifest.permission.BLUETOOTH_CONNECT) !=
                                PackageManager.PERMISSION_GRANTED) {
                            requestPermissions(new String[]{android.Manifest.permission.BLUETOOTH_CONNECT}, 102);
                            return;
                        }
                    }

                    Set<BluetoothDevice> bluetoothDeviceSet = btAdapter.getBondedDevices();
                    for (BluetoothDevice bluetoothDevice : bluetoothDeviceSet) {
                        Toast.makeText(MainActivity3.this,
                                bluetoothDevice.getName() + " - " + bluetoothDevice.getAddress(), Toast.LENGTH_LONG)
                                .show();
                    }

                    // Ask user to enable Bluetooth manually
                    Intent enableBtIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
                    startActivityForResult(enableBtIntent, 101);
                }

                Set<BluetoothDevice> bluetoothDeviceSet = btAdapter.getBondedDevices();
                for (BluetoothDevice bluetoothDevice : bluetoothDeviceSet) {
                    Toast.makeText(MainActivity3.this,
                            bluetoothDevice.getName() + " - " + bluetoothDevice.getAddress(), Toast.LENGTH_LONG)
                            .show();
                }
            }
        });

    }
}