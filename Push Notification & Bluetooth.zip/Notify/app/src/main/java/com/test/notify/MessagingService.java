package com.test.notify;

import android.annotation.SuppressLint;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.util.Log;
import androidx.annotation.NonNull;
import androidx.core.app.NotificationCompat;

import com.google.firebase.messaging.FirebaseMessagingService;
import com.google.firebase.messaging.RemoteMessage;

@SuppressLint("MissingFirebaseInstanceTokenRefresh")
public class MessagingService extends FirebaseMessagingService {
    @Override
    public void onMessageReceived(@NonNull RemoteMessage message) {
        super.onMessageReceived(message);

        String title = "Default Title";
        String body = "Default Body";

        // Get message title & body safely
        if (!message.getData().isEmpty()) {  // Check if "data" payload exists
            title = message.getData().get("title");
            body = message.getData().get("body");
        } else if (message.getNotification() != null) {  // Check if "notification" payload exists
            title = message.getNotification().getTitle();
            body = message.getNotification().getBody();
        }

        Log.i("Notify-Log", "Title: " + title);
        Log.i("Notify-Log", "Body: " + body);

        // Create Notification Channel
        NotificationManager notificationManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel notificationChannel = new NotificationChannel(
                    "C1", "Channel1", NotificationManager.IMPORTANCE_HIGH
            );
            notificationManager.createNotificationChannel(notificationChannel);
        }

        Intent intent = new Intent(this, MainActivity2.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent pendingIntent = PendingIntent.getActivity(
                this, 0, intent, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        Notification notification = new NotificationCompat.Builder(this, "C1")
                .setContentTitle(title)
                .setContentText(body)
                .setSmallIcon(R.drawable.baseline_adb_24)
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setDefaults(Notification.DEFAULT_ALL)
                .setAutoCancel(true)
                .setContentIntent(pendingIntent)  // Open MainActivity2 when clicked
                .build();

        notificationManager.notify(1, notification);
    }
}

