package com.test.sqlite;


import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;

import androidx.activity.EdgeToEdge;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        Button btn1 = findViewById(R.id.button);
        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dbClass database = new dbClass(MainActivity.this, "SQLite.db",null,1);
                new Thread(new Runnable() {
                    @Override
                    public void run() {
                        SQLiteDatabase sqLiteDatabase = database.getWritableDatabase();
                        sqLiteDatabase.execSQL("INSERT INTO `user`(`name`,`mobile`,`city`) VALUES('Tharindu','0751441764','Bandarwela')");
                    }
                }).start();
            }
        });

        Button btn2 = findViewById(R.id.button2);
        btn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dbClass database = new dbClass(MainActivity.this, "SQLite.db",null,1);
                new Thread(new Runnable() {
                    @Override
                    public void run() {
                        SQLiteDatabase sqLiteDatabase = database.getReadableDatabase();
                        Cursor cursor = sqLiteDatabase.rawQuery("SELECT * FROM `user`",new String[]{});
                        while (cursor.moveToNext()){
                          String name = cursor.getString(cursor.getColumnIndexOrThrow("name"));
                            Log.i("SQLite_App",name);
                        }
                    }
                }).start();
            }
        });

        Button btn3 = findViewById(R.id.button3);
        btn3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dbClass database = new dbClass(MainActivity.this, "SQLite.db",null,1);
                new Thread(new Runnable() {
                    @Override
                    public void run() {
                        SQLiteDatabase sqLiteDatabase = database.getReadableDatabase();

                        ContentValues contentValues = new ContentValues();
                        contentValues.put("name","Tharindu");
                        contentValues.put("mobile","0751441764");
                        contentValues.put("city","Colombo");

                        long id = sqLiteDatabase.insert("user",null,contentValues);
                        Log.i("App16Log", String.valueOf(id));
                    }
                }).start();
            }
        });

        Button btn4 = findViewById(R.id.button4);
        btn4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dbClass database = new dbClass(MainActivity.this, "SQLite.db",null,1);
                new Thread(new Runnable() {
                    @Override
                    public void run() {
                        SQLiteDatabase sqLiteDatabase = database.getReadableDatabase();
                        String projection [] = new String[]{"id","name","city"};
                        String selection = "id=? AND name=?";
                        String selectionArgs[] = new String[]{"2","Tharindu"};

                        Cursor cursor = sqLiteDatabase.query(
                                "user",
                                projection,
                                selection,
                                selectionArgs,
                                null,
                                null,
                                null
                        );
                        while (cursor.moveToNext()){
                            String id = cursor.getString(0);
                            String name = cursor.getString(1);
                            String city = cursor.getString(2);

                            Log.i("App16Log",id);
                            Log.i("App16Log",name);
                            Log.i("App16Log",city);
                        }
                    }
                }).start();
            }
        });
    }
}

class dbClass extends SQLiteOpenHelper{

    public dbClass(@Nullable Context context, @Nullable String name, @Nullable SQLiteDatabase.CursorFactory factory, int version) {
        super(context, name, factory, version);
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
//        sqLiteDatabase.execSQL("CREATE TABLE user (\n" +
//                "    id     INTEGER PRIMARY KEY AUTOINCREMENT,\n" +
//                "    name   TEXT    NOT NULL,\n" +
//                "    mobile TEXT    NOT NULL,\n" +
//                "    city   TEXT    NOT NULL\n" +
//                ");");

                sqLiteDatabase.execSQL("CREATE TABLE `user` (\n" +
                        "  `id` INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,\n" +
                        "  `name` VARCHAR(15) NOT NULL,\n" +
                        "  `mobile` VARCHAR(10) NOT NULL,\n" +
                        "  `city` VARCHAR(45) NOT NULL\n" +
                        ")");
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {

    }
}