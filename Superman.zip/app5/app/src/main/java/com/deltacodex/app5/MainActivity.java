package com.deltacodex.app5;

import android.graphics.Color;
import android.graphics.PorterDuff;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        ImageView imageView1 = findViewById(R.id.imageView);

//        btn1.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                Button btn3 = new Button(MainActivity.this);
//                btn3.setText("I am Created");
//                btn3.setBackgroundColor(Color.parseColor("#990901"));
//                btn3.setOnClickListener(new View.OnClickListener() {
//                    @Override
//                    public void onClick(View view) {
//                        Toast.makeText(MainActivity.this, "New Button Created", Toast.LENGTH_SHORT).show();
//                    }
//                });
//                LinearLayout linearLayout1 = findViewById(R.id.linearLayout1);
//                linearLayout1.addView(btn3);
//            }
//        });

        Button btn1 = findViewById(R.id.button);
        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Switch to the new drawable
                imageView1.setImageResource(R.drawable.superman);
            }
        });


        Button btn2 = findViewById(R.id.button2);
        btn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Switch to the new drawable
                imageView1.setImageResource(R.drawable.superman1);
            }
        });
    }

    public void createComponent(View view) {
        Button btn4 = new Button(MainActivity.this);
        btn4.setText("Created By new Method");
        btn4.setBackgroundColor(Color.parseColor("#016359FF"));
        btn4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(MainActivity.this, "New Method Button Created", Toast.LENGTH_SHORT).show();
            }
        });
        LinearLayout linearLayout1 = findViewById(R.id.linearLayout1);
        linearLayout1.addView(btn4);
        Toast.makeText(MainActivity.this, "Created By new Method", Toast.LENGTH_SHORT).show();
    }
}