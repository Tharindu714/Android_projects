package com.test.videoapp;

import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.CalendarView;
import android.widget.MediaController;
import android.widget.VideoView;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.Calendar;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        VideoView videoView = findViewById(R.id.videoView);
        MediaController mediaController = new MediaController(MainActivity.this);
        mediaController.setMediaPlayer(videoView);
        mediaController.setAnchorView(videoView);

videoView.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
    @Override
    public void onCompletion(MediaPlayer mediaPlayer) {
        Log.i("VideoApp","Video Ended");
    }
});
        videoView.setMediaController(mediaController);
        Uri uri = Uri.parse("https://video.fastly.steamstatic.com/store_trailers/256929315/movie480_vp9.webm?t=1675772698");
        videoView.setVideoURI(uri);
        videoView.start();

        CalendarView calendarView = findViewById(R.id.calendarView);
        calendarView.setOnDateChangeListener(new CalendarView.OnDateChangeListener() {
            @Override
            public void onSelectedDayChange(@NonNull CalendarView calendarView, int y, int m, int d) {
                Log.i("VideoApp",String.valueOf(y));
                Log.i("VideoApp",String.valueOf(m));
                Log.i("VideoApp",String.valueOf(d));
            }
        });

        Button btnCalender = findViewById(R.id.button);
        btnCalender.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                CalendarView calendarView1 = findViewById(R.id.calendarView);
                Calendar calendar = Calendar.getInstance();
                calendar.set(2026, 11,22);
                calendarView1.setDate(calendar.getTimeInMillis());
            }
        });
    }
}