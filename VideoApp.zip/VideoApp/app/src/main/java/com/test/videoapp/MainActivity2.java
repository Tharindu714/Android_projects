package com.test.videoapp;

import android.os.Bundle;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.github.mikephil.charting.animation.Easing;
import com.github.mikephil.charting.charts.BarChart;
import com.github.mikephil.charting.data.BarData;
import com.github.mikephil.charting.data.BarDataSet;
import com.github.mikephil.charting.data.BarEntry;

import java.util.ArrayList;

public class MainActivity2 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main2);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        BarChart barChart = findViewById(R.id.barchart);
        ArrayList<BarEntry> barEntryArrayList = new ArrayList<>();
        barEntryArrayList.add(new BarEntry(0,25));
        barEntryArrayList.add(new BarEntry(10,60));
        barEntryArrayList.add(new BarEntry(20,10));
        barEntryArrayList.add(new BarEntry(30,40));

        BarDataSet barDataSet = new BarDataSet(barEntryArrayList,"test");

        BarData barData = new BarData();
        barData.addDataSet(barDataSet);

        barChart.setPinchZoom(false);
        barChart.setScaleEnabled(false);
        barChart.animateY(1000, Easing.EaseInCubic);
        barChart.setDescription(null);

        barChart.setData(barData);
        barChart.invalidate();
    }
}